#include <stdio.h>		//for stderr,fprintf,stderr,printf,sprintf
#include <stdlib.h>		//for atoi,exit
#include <string.h>		//for bzero,bcopy,strcpy,strcat,strlen,strcmp
#include <unistd.h>		//for read,close,write
//#include <sys/types.h>	//for mode_t
//#include <sys/socket.h>
//#include <netinet/in.h>
#include <arpa/inet.h>		//for inet_aton,netinet/in.h,inttypes.h
#include <netdb.h>		//for sockaddr_in,AF_INET,SOCK_STREAM,socket,gethostbyname,hostent,htons,connect
#include <fcntl.h>		//for open,file permissions,opening modes
#include <iostream>
#include <openssl/md5.h>	//for md5 checksum functions

#define BUFSIZE 1024
	
using namespace std;



unsigned int sequence;
unsigned int currseq;
unsigned int currchk;


class appheader{
public:
	unsigned int seqnum;
	unsigned int chksize;
	appheader(){
		seqnum = sequence;
		currseq = sequence;
		sequence++;
	}
};

struct header
{
	unsigned int seqnum;
	unsigned int chksize;
};

char* createpacket(char* buf){
	appheader hd;
	hd.chksize = strlen(buf);
	currchk = hd.chksize;
	char* packet = (char*)malloc(hd.chksize+sizeof(appheader)+1);
	memcpy(packet,(char*)&hd,sizeof(appheader));
	strcpy(packet+sizeof(appheader),buf);
	packet[sizeof(appheader)+hd.chksize]='\0';
	return packet;
}

char* createduppacket(char* buf){
	appheader hd;
	sequence--;
	hd.chksize = strlen(buf);
	hd.seqnum = sequence;
	currchk = hd.chksize;
	char* packet = (char*)malloc(hd.chksize+sizeof(header)+1);
	memcpy(packet,(char*)&hd,sizeof(header));
	strcpy(packet+sizeof(appheader),buf);
	packet[sizeof(appheader)+hd.chksize]='\0';
	return packet;
}

header getheader(char* packet){
	header* hd = (header*)packet;
	return *hd;
}
char* getdata(char* packet){
	return packet+sizeof(appheader);
}

// int main(){
// 	char* buf = "dvssismyname";
// 	char* packet = createpacket(buf);
// 	header hd1 = getheader(packet);
// 	cout<<"seqnum: "<<hd1.seqnum<<" chksize: "<<hd1.chksize<<endl;
// 	char* bufdup = getdata(packet);
// 	cout<<"bufdup: "<<bufdup<<endl;
// }



int sendpacket(int & sockfd, char* buf,struct sockaddr_in serveraddr){
	//this function uses stop and wait protocol
	//on top of UDP protocol
	//this function can only take buffer of size less than 1024 bytes.
	//sendto(s, message, strlen(message) , 0 , (struct sockaddr *) &si_other, slen)
	//buf contains 
	int tmp;
	char* packet = createpacket(buf);
	int dgramsize = BUFSIZE+sizeof(appheader);
	char* recvpacket = (char*)malloc(dgramsize);
	//send the packet
	unsigned int slen = sizeof(serveraddr);
	if((tmp = sendto(sockfd,packet,sizeof(appheader)+strlen(buf),0,(struct sockaddr*)&serveraddr,slen))<0){
		cout<<"ERROR: while sending the packet"<<endl;
		exit(0);
	}
	int ntimeouts=0;
	
	while(1){
		bzero(recvpacket,dgramsize);
		if((recvfrom(sockfd,recvpacket,dgramsize, 0, (struct sockaddr *) &serveraddr, &slen))>=0){
			//recieved something
			header mnhd = getheader(recvpacket);
			if(mnhd.seqnum != sequence){ //if seqnum doesn't match recieve again.

				cout<<"seq num didn't match"<<endl;
				continue;
			}
			else //if seqnum match then break
			{
				cout<<"seq num matched"<<endl;
				break;
			}
		}
		ntimeouts++;
		cout<<"Packent "<<ntimeouts<<" failed and sent again "<<endl;
		realloc(packet,0);
		//creating packet and sending again.
		packet = createduppacket(buf);
		if((tmp = sendto(sockfd,packet,sizeof(appheader)+strlen(buf),0,(struct sockaddr*)&serveraddr,slen))<0){
			cout<<"ERROR: while sending the packet"<<endl;
			exit(0);
		}
	}
	return tmp;
}

void recvpack(int &sockfd, char* recvpacket,int dgramsize,struct sockaddr_in& clientaddr,unsigned int clientlen){

	bzero(recvpacket, BUFSIZE);
	int result=-1;
	while(result==-1){
		if((result=recvfrom(sockfd,recvpacket,dgramsize, 0, (struct sockaddr *) &clientaddr, &clientlen))<0){
			cout<<"ERROR: while recieving from client "<<endl;
			exit(0);
		}
		if(sequence == getheader(recvpacket).seqnum){
			break;
		}
		else{
			result = -1;
		}
	}
	header hd = getheader(recvpacket);
	return;
}

int sendack(int &sockfd,struct sockaddr_in& clientaddr,unsigned int clientlen, unsigned int recvseqnum,char* str){
	char* ack = (char*)malloc(BUFSIZE) ;
	strcpy(ack,str);
	int j = 1;
	if(recvseqnum == sequence){
		sequence++;
	}
	else if(recvseqnum!=sequence-1){
		//false alarm i.e no need to use the packet recieved and acknowledgement need not be sent.
		return -1;
	}
	else if(recvseqnum == sequence -1){
		//false alarm i.e no need to use the packet recieved but acknowledgement should be sent
		j = -1;
	}
	ack = createpacket(ack);
	// cout<<"acknowledgement: "<<ack<<endl;
	int result;
	if((result=sendto(sockfd,ack,sizeof(appheader)+strlen(str), 0, (struct sockaddr *) &clientaddr, clientlen))<0){
		cout<<"ERROR: while sending acknowledgement to client: "<<result<<endl;
	}
	realloc(ack,0);
	return j;
}

int main(int argc, char **argv)
{
	int sockfd,portno,n;
	struct sockaddr_in serveraddr;
	struct hostent *server;
	char *hostname;
	char buf[BUFSIZE];
	int fd;
	char* st = "ACK";
	sequence = 0;
	//mode_t mode;
	
	if (argc != 4)
	{
		 fprintf(stderr,"usage: %s <hostaddr(IPv4)> <port> <filename>\n", argv[0]);
		 exit(0);
	}
	hostname = argv[1];
	portno = atoi(argv[2]);
	
	sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	//set sock options and mention the time out for the recv.
	struct timeval tv; 
    int timeouts = 0;
	tv.tv_sec = 5;
	tv.tv_usec = 0;
	if (setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, (char *)&tv,  sizeof(tv)))
	{
		cout<<"ERROR: enable to set socket options"<<endl;
		exit(0);
	}
	if (sockfd < 0)
	{ 
		cerr<<"ERROR opening socket\n";
		exit(1);
	}
	
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(portno);
	inet_aton(hostname,&serveraddr.sin_addr);
	
	
	//opening file
	fd = open(argv[3],O_RDONLY,S_IRUSR);
	if(fd<0)
	{
		fprintf(stderr,"ERROR, opening file %s\n", argv[3]);
		exit(0);
	}
	//finding size of file
	long long int sizeoffile = 0;
	int bytesread;
	while(bytesread = read(fd,buf,1024))
	{
		sizeoffile+=bytesread;
	}
	close(fd);
	
	cout<<sizeoffile<<endl;
	//file is reopened to make the file pointer to point to the start
	fd = open(argv[3],O_RDONLY,S_IRUSR);
	//creating filename filesize string to send no.of chunks
	long long int chunks = (sizeoffile%1024==0)?sizeoffile/1024 : sizeoffile/1024+1;
	bzero(buf, BUFSIZE);
	strcpy(buf,argv[3]);
	strcat(buf," ");
	char str[21];
	char strch[21];
	sprintf(strch,"%lld",chunks);
	sprintf(str,"%lld ",sizeoffile);
	strcat(buf,str);
	strcat(buf,strch);
	
	cout<<"<filename filesize no. of chunks> string to send is: "<<buf<<endl;
	
	//write <filename filesize> into buffer
	n = sendpacket(sockfd, buf, serveraddr);
	if (n < 0)
	{ 
		cerr<<"ERROR writing to socket\n";
		exit(1);
	}
	
	bzero(buf, BUFSIZE);
	
	while(read(fd,buf,BUFSIZE-1))
	{
		sendpacket(sockfd, buf, serveraddr);
		bzero(buf, BUFSIZE);
	}
	close(fd);
	
	cout<<"File successfully sent.\n";
	cout<<"Waiting for md5sum.\n";

	//calculating the checksum.
	unsigned char c[MD5_DIGEST_LENGTH];
	char filehash[MD5_DIGEST_LENGTH*2+1] = "";
	char temphash[3];
	bzero(buf, BUFSIZE);
	int i;
	FILE *inFile = fopen (argv[3], "rb");
	MD5_CTX mdContext;
	int bytes;
	unsigned char data[1024];
	
	MD5_Init (&mdContext);
	while ((bytes = fread (data, 1, 1024, inFile)) != 0)
	    MD5_Update (&mdContext, data, bytes);
	MD5_Final (c,&mdContext);
	
	fclose (inFile);
	
	for(i = 0; i < MD5_DIGEST_LENGTH; i++)
	{ 
		sprintf(temphash,"%02x", c[i]);
		strcat(filehash,temphash);
	}
	
	bzero(buf, BUFSIZE);
	// n = read(sockfd, buf, BUFSIZE);

	// if (n < 0)
	// {
	// 	cerr<<"ERROR reading from socket\n";
	// 	exit(1);
	// }
	//recieve the md5 sum and send an acknowledgement.
	unsigned int slen = sizeof(serveraddr);
	int dgramsize = BUFSIZE+sizeof(appheader);
	char* recvpacket = (char*)malloc(dgramsize);
	recvpack(sockfd, recvpacket, dgramsize, serveraddr, slen);
	strcpy(buf,getdata(recvpacket));
	cout<<"md5sum recieved from server : "<<buf<<endl;
	cout<<"md5sum calculated on client : "<<filehash<<endl;
	
	if(!strcmp(buf,filehash))
	{
		cout<<"MD5 Matched\n";
	}
	else
	{
		cout<<"MD5 not Matched\n";
	}
	// str = "ACK";
	//send acknowledgement
	int nwpck = sendack(sockfd, serveraddr, slen, sequence-1, st);
	close(sockfd);
	return 0;
	
}
