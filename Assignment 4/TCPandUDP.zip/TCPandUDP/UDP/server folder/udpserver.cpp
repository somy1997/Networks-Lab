#include <stdio.h>			//for printf
#include <unistd.h>			//for read,write,close
#include <stdlib.h>			//for exit,atoi
#include <string.h>			//for bzero,strtok,strcpy,strlen
#include <netdb.h>			//netinet/in.h,sys/socket.h,hostent,gethostbyaddress
#include <arpa/inet.h>		//for inet_ntoa,netinet/in.h,inttypes.h
#include <fcntl.h>			//for open
#include <iostream>
#include <openssl/md5.h>	//for md5 checksum functions

#define BUFSIZE 1024

using namespace std;

//stop and wait protocol:
//client sends a data packet with seq num i and it will wait for acknowledgement for 1 sec and it will retransmit same data packet with
//same seqnum i and it will recieve acknowledgement of seqnum i+1 only then it start sending i+1'th packet.
//at the server's side if curr seq num = i and it recieved a packet i then it is the first time it found something new and currseq numb will
//become i+1 and it will send a packet with acknowledgement i+1. if a packet with i-1 is recieved then it will send the packet with acknow
//ledgment i. so if currseqnum = recvseqnum {currseqnum++; send(packet with currseqnum)} else {send(packet with currseqnum)};



unsigned int sequence;
unsigned int currseq;
unsigned int currchk;


class appheader{
public:
	unsigned int seqnum;
	unsigned int chksize;
	appheader(){
		seqnum = sequence;
		currseq = sequence;
	}
};

struct header
{
	unsigned int seqnum;
	unsigned int chksize;
};




char* createpacket(char* buf){
	appheader hd;
	hd.chksize = strlen(buf);
	currchk = hd.chksize;
	char* packet = (char*)malloc(hd.chksize+sizeof(appheader)+1);
	memcpy(packet,(char*)&hd,sizeof(appheader));
	strcpy(packet+sizeof(appheader),buf);
	packet[sizeof(appheader)+hd.chksize]='\0';
	return packet;
}


char* createduppacket(char* buf){
	appheader hd;
	sequence--;
	hd.chksize = strlen(buf);
	hd.seqnum = sequence;
	currchk = hd.chksize;
	char* packet = (char*)malloc(hd.chksize+sizeof(header)+1);
	memcpy(packet,(char*)&hd,sizeof(header));
	strcpy(packet+sizeof(appheader),buf);
	packet[sizeof(appheader)+hd.chksize]='\0';
	return packet;
}


header getheader(char* packet){
	header* hd = (header*)packet;
	return *hd;
}
char* getdata(char* packet){
	return packet+sizeof(appheader);
}


int sendpacket(int & sockfd, char* buf,struct sockaddr_in serveraddr){
	//this function uses stop and wait protocol
	//on top of UDP protocol
	//this function can only take buffer of size less than 1024 bytes.
	//sendto(s, message, strlen(message) , 0 , (struct sockaddr *) &si_other, slen)
	//buf contains 
	int tmp;
	char* packet = createpacket(buf);
	int dgramsize = BUFSIZE+sizeof(appheader);
	char* recvpacket = (char*)malloc(dgramsize);
	//send the packet
	unsigned int slen = sizeof(serveraddr);
	if((tmp = sendto(sockfd,packet,sizeof(appheader)+strlen(buf),0,(struct sockaddr*)&serveraddr,slen))<0){
		cout<<"ERROR: while sending the packet"<<endl;
		exit(0);
	}
	int ntimeouts=0;
	
	while(1){
		bzero(recvpacket,dgramsize);
		if((recvfrom(sockfd,recvpacket,dgramsize, 0, (struct sockaddr *) &serveraddr, &slen))>=0){
			//recieved something
			header mnhd = getheader(recvpacket);
			if(mnhd.seqnum != sequence){ //if seqnum doesn't match recieve again.

				cout<<"seq num didn't match"<<mnhd.seqnum<<" "<<sequence<<endl;
				continue;
			}
			else //if seqnum match then break
			{
				cout<<"seq num matched"<<endl;
				break;
			}
		}
		ntimeouts++;
		cout<<"Packent "<<ntimeouts<<" failed and sent again "<<endl;
		realloc(packet,0);
		//creating packet and sending again.
		packet = createduppacket(buf);
		if((tmp = sendto(sockfd,packet,sizeof(appheader)+strlen(buf),0,(struct sockaddr*)&serveraddr,slen))<0){
			cout<<"ERROR: while sending the packet"<<endl;
			exit(0);
		}
	}
	return tmp;
}



unsigned int recvpackettmout(int &sockfd, char* recvpacket,int dgramsize,struct sockaddr_in& clientaddr,unsigned int clientlen){

	bzero(recvpacket, BUFSIZE);
	int result;
	if((result=recvfrom(sockfd,recvpacket,dgramsize, 0, (struct sockaddr *) &clientaddr, &clientlen))<0){
		cout<<"ERROR: while recieving from client "<<endl;
		exit(0);
	}
	header hd = getheader(recvpacket);
	return hd.seqnum;
}

unsigned int recvpack(int &sockfd, char* recvpacket,int dgramsize,struct sockaddr_in& clientaddr,unsigned int clientlen){

	bzero(recvpacket, BUFSIZE);
	int result=-1;
	while(result==-1){
		if((result=recvfrom(sockfd,recvpacket,dgramsize, 0, (struct sockaddr *) &clientaddr, &clientlen))<0){
			cout<<"ERROR: while recieving from client "<<endl;
			
		}
		if(sequence == getheader(recvpacket).seqnum){
			break;
		}
		else{
			result = -1;
		}
	}
	header hd = getheader(recvpacket);
	return hd.seqnum;
}

int sendack(int &sockfd,struct sockaddr_in& clientaddr,unsigned int clientlen, unsigned int recvseqnum,char* str){
	char* ack = (char*)malloc(BUFSIZE) ;
	strcpy(ack,str);
	int j = 1;
	if(recvseqnum == sequence){
		sequence++;
	}
	else if(recvseqnum!=sequence-1){
		//false alarm i.e no need to use the packet recieved and acknowledgement need not be sent.
		return -1;
	}
	else if(recvseqnum == sequence -1){
		//false alarm i.e no need to use the packet recieved but acknowledgement should be sent
		j = -1;
	}
	ack = createpacket(ack);
	// cout<<"acknowledgement: "<<ack<<endl;
	int result;
	if((result=sendto(sockfd,ack,sizeof(appheader)+strlen(str), 0, (struct sockaddr *) &clientaddr, clientlen))<0){
		cout<<"ERROR: while sending acknowledgement to client: "<<result<<endl;
	}
	realloc(ack,0);
	return j;
}

int main(int argc, char **argv)
{
	int sockfd;
	int portno;
	socklen_t clientlen;				//unsigned integer
	struct sockaddr_in serveraddr;
	struct sockaddr_in clientaddr;
	struct hostent *hostp;
	char buf[BUFSIZE];
	char *hostaddrp;
	int n,recvseqnum;
	char* str = "ACK";
	sequence = 0;
	if (argc != 2)
	{
		cerr<<"usage: "<<argv[0]<<" <port>\n";
		exit(1);
	}
	
	portno = atoi(argv[1]);
	//create a socket 
	sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if (sockfd < 0)
	{ 
		cerr<<"ERROR opening socket\n";
		exit(1);
	}
	struct timeval tv; 
    int timeouts = 0;
	tv.tv_sec = 5;
	tv.tv_usec = 0;
	if (setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, (char *)&tv,  sizeof(tv)))
	{
		cout<<"ERROR: enable to set socket options"<<endl;
		exit(0);
	}
	bzero((char*)&serveraddr,sizeof(serveraddr));
	
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons((unsigned short)portno);
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
	
	if (bind(sockfd,(struct sockaddr *)&serveraddr,sizeof(serveraddr)) < 0) 
	{
		cerr<<"ERROR on binding\n";
		exit(1);
	}
	printf("Server Running ....\n\n");
	clientlen = sizeof(clientaddr);
	int dgramsize = BUFSIZE+sizeof(appheader);
	char* recvpacket = (char*)malloc(dgramsize);
	char* ackpacket = (char*)malloc(dgramsize);
	
	
	//THIS code is to recieve filename filesize and no. of chunks.
	recvseqnum = recvpack(sockfd, recvpacket, dgramsize, clientaddr, clientlen);
	//decode the recieved packet into header and data.
	char filename[100];
	char* dta = getdata(recvpacket);
	cerr<<"DEBUG: "<<dta<<endl;
	strcpy(filename,strtok(dta," "));
	cout<<"Name of the file to be recieved from the host : "<<filename<<endl;
	char* size = strtok(NULL," ");
	long long int sizeoffile = atoi(size);
	cout<<"Size of the file to be recieved from the host : "<<sizeoffile<<endl;
	char* chunkstr = strtok(NULL," ");
	long long int num_chunks = atoi(chunkstr);
	cout<<"No. of chunks of the file from the host: "<<num_chunks<<endl;
	int nwpck = sendack(sockfd, clientaddr, clientlen,recvseqnum,str);//if nwpck is 1 that means a new packet is recieved.


	//THIS code is for recieving the data of the file.
	int fd = open(filename,O_WRONLY|O_CREAT|O_TRUNC,S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH);
	if(fd<0)
	{
		cerr<<"Error creating file\n";
		exit(1);
	}
	bzero(buf, BUFSIZE);
	while(1)
	{
		recvseqnum = recvpack(sockfd, recvpacket, dgramsize, clientaddr, clientlen);
		nwpck = sendack(sockfd, clientaddr, clientlen,recvseqnum,str);
		if(nwpck==-1)
			continue;
		strcpy(buf,getdata(recvpacket));
		sizeoffile-=strlen(buf);
		write(fd,buf,strlen(buf));
		if(sizeoffile == 0)
			break;
	}
	close(fd);
	cout<<"File recieved successfully from the host."<<endl;
	
	//THIS code is to calculate MD5 checksum of the file recieved and to send the MD5 checksum to the client.
	unsigned char c[MD5_DIGEST_LENGTH];
	char temphash[3];
	bzero(buf, BUFSIZE);
	int i;
	FILE *inFile = fopen (filename, "r");
	if(inFile == NULL)
	{
		cerr<<"File could not be opened for calculating md5sum.\n";
		exit(0);
	}
	MD5_CTX mdContext;
	int bytes;
	unsigned char data[1024];
	MD5_Init (&mdContext);
	while ((bytes = fread (data, 1, 1024, inFile)) != 0)
	    MD5_Update (&mdContext, data, bytes);
	MD5_Final (c,&mdContext);
	fclose (inFile);
	for(i = 0; i < MD5_DIGEST_LENGTH; i++)
	{ 
		sprintf(temphash,"%02x", c[i]);
		strcat(buf,temphash);
	}
	cout<<"md5sum calculated for "<<filename<<" : "<<buf<<endl;
	cout<<"Sending md5sum to host\n";
	char* bf = &buf[0];
	n = sendpacket(sockfd, bf, clientaddr);
	cout<<"md5sum successfully sent.\n\n";
	close(sockfd);
}
