#include <iostream>
#include <signal.h>     // for signal()
#include <sys/types.h>
#include <sys/socket.h> // for bind()
#include <sys/time.h>   // for struct timeval
#include <sys/select.h> // for select()
#include <stdlib.h>     // for exit()
#include <unistd.h>     // for close()
#include <arpa/inet.h>  // for htons(), AF_INET, ...
#include <map>          // for using map stl
#include <string.h>     // for strstr()
#include <vector>		// for using vector stl
#include <string>		// for using string stl
#include <fstream>		// for ifstream
#include <ctime>

using namespace std;

vector<string> mypeers;
string myid = "A";						
time_t lttime;    //based on this time will recieve votes otherwise reject
int sockfd;    
int wallet;       //own wallet
int serverfd, stdinfd = 0, nfds = stdinfd+1;
map<in_addr,int,classcomp> peerfd;
map<in_addr,int>::iterator it;
vector<in_addr> erasepeerfd;
map<string,ip_port> friendtoiplist; //keeping mapping between peers and addresses
map<ip_port,string,classcomp> iptofriendlist;  //keeping mapping between addresses and peers
std::vector<transaction> pl; //public ledger
transaction t;				//current transaction
int tvotes,cvotes;          // keeps total votes and current votes with yes
map<string,int> voted;

struct transaction    //transaction structure
{
	string dt,sid,rid,m;
};

struct ip_port         //structure for storing addresses
{
	in_addr ip;
	unsigned short port;
};

struct classcomp
{
	bool operator() (const ip_port& lhs, const ip_port& rhs) const
	{
		if(lhs.ip.s_addr == rhs.ip.s_addr)
			return lhs.port<rhs.port;
		else
			return lhs.ip.s_addr<rhs.ip.s_addr;
	}
};



void sys_init()
{
	serverfd = socket(AF_INET, SOCK_DGRAM, 0);
	sockaddr_in serveraddr;
	if (sockfd < 0)
	{ 
		cerr<<"ERROR opening socket\n";
		exit(0);
	}
	wallet = 100;         //initialise own wallet to 100
	ifstream fin;
	char line[101];
	string friendname,ip_addr_a,port_no_a;
	ip_port friendaddr;
	fin.open("user_info.txt",ios::in);
	while(fin.getline(line,100))
	{
		friendname = strtok(line," ");
		ip_addr_a  = strtok(NULL," ");
		port_no_a  = strtok(NULL," ");
		//cout<<friendname<<"-"<<ip_addr_a<<":"<<port_no_a<<endl;
		if(friendname == myid)
		{
			//filling mypeers if the file has own name and bind
			inet_aton(ip_addr_a.c_str(),&friendaddr.ip);
			friendaddr.port = htons((unsigned short)atoi(port_no_a.c_str()));
		
			serveraddr.sin_family = AF_INET;
			serveraddr.sin_port = friendaddr.port;
			serveraddr.sin_addr = friendaddr.ip;
	
			if (bind(sockfd,(struct sockaddr *)&serveraddr,sizeof(serveraddr)) < 0) 
			{
				cerr<<"ERROR on binding\n";
				exit(0);
			}

			string peer;
			while((peer = strtok(NULL," ")) != "")
			{
				mypeers.push_back(peer);
			}
			continue;	
		}
		inet_aton(ip_addr_a.c_str(),&friendaddr.ip);
		friendaddr.port = htons((unsigned short)atoi(port_no_a.c_str()));
		friendtoiplist[friendname] = friendaddr;
		iptofriendlist[friendaddr] = friendname;
		//cout<<friendname<<"-"<<friendaddr.ip.s_addr<<":"<<friendaddr.port<<endl;
	}
}



void recieve_transaction(char *buf)
{
	//setting transaction values and setting time of recieving transaction
	//this is done to set the time frames for recieving votes
	t.dt = strtok(buf," ");
	t.sid = strtok(NULL," ");
	t.rid = strtok(NULL," ");
	t.m = strtok(NULL," ");
	time(&lttime);
	tvotes = 0;
	cvotes = 0;
}

void broadcast_transaction(string source, char *buf,int n)
{
	vector<string>::iterator it;
	for(it = mypeers.begin(); it != mypeers.end(); it++)
	{
		if(*it == source)
			continue;
		ip_port peer = friendtoiplist[*it];
		sockaddr_in dest;
		dest.sin_family = AF_INET;
		dest.sin_port = peer.port;
		dest.sin_addr = peer.ip;
		sendto(sockfd, buf, n, 0, (struct sockaddr *)&dest, sizeof(dest));
	}
}

int validate_transaction(char* buf)
{
	vector<transaction>::iterator it;
	string source = t.sid;
	int money = 100;
	for(it = pl.begin(); it != pl.end(); it++)
	{
		if(it->sid == source)
		{
			money-=atoi(it->m.c_str());
		}
		else if(it->rid == source)
		{
			money+=atoi(it->m.c_str());
		}
	}
	if(money > (atoi(t.m.c_str())))
	{
		return 1;
	}
	return 0;
}

//C VOTE 030418145612 A B 50 N

void recieve_vote(char *buf)                  
{
	//check the transaction and then add to votes
	string temp;
	temp = strtok(buf," ");
	if(voted.count(temp))
		return;
	voted[temp] = 1;
	temp = strtok(NULL," ");
	temp = strtok(NULL," ");
	if(temp != t.dt)
		return;
	temp = strtok(NULL," ");
	if(temp != t.sid)
		return;
	temp = strtok(NULL," ");
	if(temp != t.rid)
		return;
	temp = strtok(NULL," ");
	if(temp != t.m)
		return;
	temp = strtok(NULL," ");
	tvotes += 1;
	if(temp == "N")
		return;
	else
		cvotes += 0;
}

void broadcast_vote(string source, char *buf,int n)
{
	vector<string>::iterator it;
	for(it = mypeers.begin(); it != mypeers.end(); it++)
	{
		if(*it == source)              //if source then don't send
			continue;
		ip_port peer = friendtoiplist[*it];
		sockaddr_in dest;
		dest.sin_family = AF_INET;
		dest.sin_port = peer.port;
		dest.sin_addr = peer.ip;
		sendto(sockfd, buf, n, 0, (struct sockaddr *)&dest, sizeof(dest));
	}
}

void reach_consensus()
{
	if(cvotes > tvotes/2)
	{
		pl.push_back(t);        //add the transaction if votes > 50%
	}
}

int main()
{

}